# Saigon Noodle Bar — sitio web

Sitio de 5 páginas HTML:
- index.html — Inicio
- carta.html — Carta
- especiales.html — Platos especiales
- entradas.html — Entradas
- ubicacion.html — Ubicación y contacto

Todos los archivos están listos para subir a GitHub Pages. No hace falta instalar nada: subí la carpeta completa manteniendo la carpeta `assets`.
